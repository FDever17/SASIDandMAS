#!/bin/sh

sudo su -c './scripts/incorrectJVM.sh' sas > /dev/null 2>&1

./restartModelPublish.sh > /dev/null 2>&1