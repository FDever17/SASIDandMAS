#!/bin/sh

sudo su -c './scripts/incorrectJVM.sh' sas > /dev/null 2>&1

./scripts/restartModelPublish.sh > /dev/null 2>&1
