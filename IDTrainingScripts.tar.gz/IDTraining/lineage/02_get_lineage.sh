HOSTNAME="$1"
URLBASE="https://$HOSTNAME"
token=`cat  ~/.sas/$HOSTNAME.token`

if [[ ($# -ne 2 && $# -ne 3 && $# -ne 4) ]] ; then
  echo 'At least 1 parameter required'
  echo 'Parameters are:'
  echo 'First parameter (mandatory): SAS WebApp Server Hostname'
  echo 'Second parameter (mandatory): DF object URI'
  echo 'Third parameter (optional): base path of locations excluded from results'
  echo 'Fourth parameter (optional): EXCLUDE_MODELREPOSITORY - if specified then objects located under  /Model Repositories/DMRepository/ + base path will be not listed'
  exit;
fi


DF_URI=$2
BASE_LOCATION="$3"

# gets location path based on given object URI
# Takes 1 input only - object URI
# Output is object URI and object location PATH
# Example: get_location "/treatmentDefinitions/definitions/7e70258b-b6cc-46a7-92cc-828de702e91f"
get_location() {
  separator='|'
  name=`curl --insecure -s -X GET "$URLBASE:443$1" -H 'Accept: application/json' -H 'Content-Type: application/json;charset=utf-8' -H "Authorization: Bearer $token" | tr ',' '\n' | grep -E '\"name\":\"' | head -1 | cut -d '"' -f4 `
  location=`curl --insecure -s -X GET "$URLBASE:443/folders/ancestors?childUri=$1" -H 'Accept: application/vnd.sas.content.folder.ancestor+json' -H 'Content-Type: application/json;charset=utf-8' -H "Authorization: Bearer $token" | tr ',' '\n' | grep -E '\"name\":\"' | cut -d '"' -f4 | tac | tr '\n' '\/'`
  echo -n $name$separator$1$separator'/'$location';'
}

# recursively get all child objects URIs and for each of them call get_location
get_children() {
  count=`curl --insecure -s -X GET "$URLBASE:443/relationships/relationships/?resourceUri=$1" -H 'Accept: application/json' -H 'Content-Type: application/json;charset=utf-8' -H "Authorization: Bearer $token" | tr ',' '\n' | grep -E '\"count\":' | cut -d ':' -f2`
  get_location "$1"

  if (( $count > 0 )); then
  if [[ ! "$1" =~ "/decisions/codeFiles/" ]]; then
    children=`curl --insecure -s -X GET "$URLBASE:443/relationships/relationships/?limit=1000&resourceUri=$1" -H 'Accept: application/json' -H 'Content-Type: application/json;charset=utf-8' -H "Authorization: Bearer $token"  | tr ',' '\n' | grep -E '\"relatedResourceUri\":' | cut -d '"' -f4 | sed 's/\/revisions\/.*//g'`
    for child in $children
    do
      get_location "$child"
      if [[ ! "$child" =~ "/decisions/codeFiles/" ]]; then
        get_children "$child"
      fi
    done
  fi
  fi
}

all_children=`get_children $DF_URI`

if [[ ($# -eq 4) ]] ; then
  echo "Objects not located within base location path:"
  echo $all_children | tr ';' '\n' | grep -v "|$BASE_LOCATION" | grep -v "|/Model Repositories/DMRepository$BASE_LOCATION"
fi
if [[ ($# -eq 3) ]] ; then
  echo "Objects not located within base location path:"
  echo $all_children | tr ';' '\n' | grep -v "|$BASE_LOCATION"
fi
if [[ ($# -eq 2) ]] ; then
  echo "All objects are:"
  echo $all_children | tr ';' '\n'
fi
