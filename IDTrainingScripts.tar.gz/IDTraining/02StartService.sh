#!/bin/sh

./scripts/startBR.sh > /dev/null 2>&1
