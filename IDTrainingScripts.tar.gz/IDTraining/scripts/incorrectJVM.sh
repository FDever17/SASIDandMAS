#!/bin/sh


. /opt/sas/viya/config/consul.conf 

/opt/sas/viya/home/bin/sas-bootstrap-config --token-file /opt/sas/viya/config/etc/SASSecurityCertificateFramework/tokens/consul/default/client.token kv write --force config/modelPublish/jvm/java_option_xmx "- Xmx 768m"


