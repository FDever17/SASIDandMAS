#!/bin/sh

sudo systemctl start sas-viya-businessruleservices-default.service 
