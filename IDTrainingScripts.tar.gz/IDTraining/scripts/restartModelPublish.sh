#!/bin/sh

sudo systemctl restart sas-viya-modelpublish-default