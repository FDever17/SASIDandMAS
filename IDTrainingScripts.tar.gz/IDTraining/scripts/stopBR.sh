#!/bin/sh

sudo systemctl stop sas-viya-businessruleservices-default.service 
