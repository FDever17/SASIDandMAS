#!/bin/sh

sudo su -c './scripts/fixJVM.sh' sas > /dev/null 2>&1

./scripts/restartModelPublish.sh > /dev/null 2>&1