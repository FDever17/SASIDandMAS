#!/bin/sh

/opt/sas/viya/home/bin/sas-admin 