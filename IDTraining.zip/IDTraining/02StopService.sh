#!/bin/sh

./scripts/stopBR.sh > /dev/null 2>&1