#!/bin/bash
if [[ ($# -ne 1) ]] ; then
  echo '1 parameter required'
  echo 'Parameters are:'
  echo 'First parameter: WebApp server hostname'
  exit;
fi
HOSTNAME=$1


URLBASE="https://$HOSTNAME:443"
echo -n 'Username: '
read USERNAME
echo -n 'Password: '
read -s PASSWORD
curl --insecure --location --request POST "$URLBASE/SASLogon/oauth/token?grant_type=password&username=$USERNAME&password=$PASSWORD" --header 'Authorization: Basic c2FzLmVjOg==' > ~/.sas/$HOSTNAME.token.response
cat ~/.sas/$HOSTNAME.token.response | cut -d'"' -f4 > ~/.sas/$HOSTNAME.token
rm -f  ~/.sas/$HOSTNAME.token.response

