#!/bin/sh

sudo su -c './scripts/fixJVM.sh' sas > /dev/null 2>&1

./restartModelPublish.sh > /dev/null 2>&1